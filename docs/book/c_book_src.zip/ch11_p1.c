#include <stdio.h>

int main(int argc, char **argv) {
  printf("argc=%d\n", argc);
  return 0;
}
