#ifndef FEATURE_H
#define FEATURE_H

void feature(void);

#endif
