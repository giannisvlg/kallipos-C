#ifndef UTILS_H
#define UTILS_H

void util_function(void);

#endif
