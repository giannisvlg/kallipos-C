int a = 42;
void foo(void) { a++; }
