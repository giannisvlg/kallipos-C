#include <stdio.h>

int main(void) {
  int a = 42;
  if (1) {
    int b = 73;
    a += 1;
    printf("%d\n", a);
  }
}
