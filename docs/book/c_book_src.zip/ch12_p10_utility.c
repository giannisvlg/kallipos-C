#include "ch12_p10_utility.h"

int add_numbers(int a, int b) { return a + b; }
