#include <stdio.h>

int main(void) {
  char s[10];
  scanf("%9s", s);
  printf("%s", s);
}