#include <stdio.h>

int main(void) {
  // clang-format off
         int a=    42;
    printf("a=%d\n", a);
  // clang-format on
  int b = 73;
  printf("b=%d\n", b);
  return 0;
}
