#include "ch12_p10_utility.h"
#include <stdio.h>

int main(void) {
  int result = add_numbers(2, 3);
  printf("The result is %d\n", result);
  return 0;
}
