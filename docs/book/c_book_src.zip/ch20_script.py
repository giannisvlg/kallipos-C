def reverse_string(string):
    return string[::-1]
