#define FOO 1729

int main(void) {
  int foo = FOO;
  int FOOBAR = FOO;
  char *bar = "FOO and BAR are placeholder names in computer programming";
}
