#include <stdio.h>

int main(void) {
  char s[10];
  scanf("%s", s);
  printf("%s", s);
}
