#include <stdio.h>

int foo(void) { return 42; }

int bar(void) { return 73; }

int main(void) { printf("%d\n", foo()); }
