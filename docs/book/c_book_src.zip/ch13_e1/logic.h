#ifndef LOGIC_H
#define LOGIC_H

#include "interval.h"

int count_overlapping(Interval intervals[], int size, Interval target);

#endif
