#ifndef MATH_FUNCTIONS_H
#define MATH_FUNCTIONS_H

int add(int x, int y);
int multiply(int x, int y);

#endif
