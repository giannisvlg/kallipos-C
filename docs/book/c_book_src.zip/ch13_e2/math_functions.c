#include "math_functions.h"

int add(int x, int y) { return x + y; }

int multiply(int x, int y) { return x * y; }
