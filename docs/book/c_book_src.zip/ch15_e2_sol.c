#include <stdio.h>

int main(void) {
  int x;
  printf("Input an integer : ");
  scanf("%d", &x);
  printf("You entered : %d \n", x);
  return 0;
}
