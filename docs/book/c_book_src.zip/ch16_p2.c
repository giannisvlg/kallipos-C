#include <stdio.h>

int main(void) {
  int a = 42, b;
  a += b;
  printf("a=%d\n", a);
  return 0;
}
