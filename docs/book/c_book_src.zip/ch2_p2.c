#include <stdio.h>

int main(void) {
  printf("This string contains newline characters \nNew Line\n");
  printf("This string contains a tab character \tTabbed Text\n");
  printf("This string contains a backslash character \\ \n");
  printf("This string contains \"Double Quotes\"\n");
  printf("This string contains \'Single Quotes\'\n");
  printf("This string contains backspace characters:Learn C++\b\b\bplain C\n");
  printf("This string makes a beep sound \a \n");
  printf("This string contains a hexadecimally encoded symbol \xFB \n");
  printf("This string contains the NULL character\0 unreached text");
  return 0;
}
