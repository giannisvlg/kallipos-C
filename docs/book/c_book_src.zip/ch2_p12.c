#include <stdio.h>

int main(void) {
  printf("1 > 2 is evaluated as %d\n", 1 > 2);
  printf("2 <= 2 is evaluated as %d\n", 2 <= 2);
  return 0;
}
