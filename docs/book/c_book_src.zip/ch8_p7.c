#include <stdio.h>

int main(void) {
  char word1[10] = "Simple";
  char word2[] = "Another";
  printf("word1=%s word2=%s \n", word1, word2);
  return 0;
}
